__title__ = 'lshash'
__author__ = 'Xuantang Cun (xuantang.cun@gmail.com)'
__license__ = 'MIT'
__version__ = '1.0dev'

from lshash import LSHash
